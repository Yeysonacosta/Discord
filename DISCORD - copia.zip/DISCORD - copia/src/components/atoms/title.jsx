const Title = ({ children }) => <h1>{children}</h1>;
export default Title;