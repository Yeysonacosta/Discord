const Input = ({ type, name }) => <input type={type} name={name} />;
export default Input;