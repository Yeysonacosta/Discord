import CardBody from '../organisms/CardBody';

const CardPage = () => {
  return (
    <div className="card-container">
      <CardBody />
    </div>
  );
};

export default CardPage;